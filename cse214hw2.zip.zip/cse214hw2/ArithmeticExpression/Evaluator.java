package cse214hw2.ArithmeticExpression;

public interface Evaluator {

    double evaluate(String expression);


}
